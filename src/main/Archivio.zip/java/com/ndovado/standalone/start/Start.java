package com.ndovado.standalone.start;

import com.ndovado.standalone.frames.LoginFrame;

public class Start {

	public static void main(String[] args) {
		@SuppressWarnings("unused")
		LoginFrame Window = new LoginFrame();

	}
}