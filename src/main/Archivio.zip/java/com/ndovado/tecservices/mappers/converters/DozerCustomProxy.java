package com.ndovado.tecservices.mappers.converters;

import org.dozer.util.DozerProxyResolver;

public class DozerCustomProxy implements DozerProxyResolver {

	@Override
	public boolean isProxy(Class<?> clazz) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public <T> T unenhanceObject(T object) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Class<?> getRealClass(Class<?> clazz) {
		// TODO Auto-generated method stub
		return null;
	}

}
