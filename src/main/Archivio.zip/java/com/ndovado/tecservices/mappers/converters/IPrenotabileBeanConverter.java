package com.ndovado.tecservices.mappers.converters;

import org.dozer.DozerConverter;

import com.ndovado.dominio.core.Camera;
import com.ndovado.dominio.prenotazioni.IPrenotabile;
import com.ndovado.dominio.servizi.ServizioAggiuntivo;
import com.ndovado.tecservices.mappers.CameraMapper;
import com.ndovado.tecservices.mappers.ServizioAggiuntivoMapper;
import com.ndovado.webapp.beans.core.CameraBean;
import com.ndovado.webapp.beans.prenotazioni.IPrenotabileBean;
import com.ndovado.webapp.beans.servizi.ServizioAggiuntivoBean;

public class IPrenotabileBeanConverter extends DozerConverter<IPrenotabile, IPrenotabileBean>  {

	private CameraMapper cmapper = CameraMapper.getInstance();
	private ServizioAggiuntivoMapper samapper = ServizioAggiuntivoMapper.getInstance();
			
	public IPrenotabileBeanConverter() {
		super(IPrenotabile.class, IPrenotabileBean.class);
	}

	@Override
	public IPrenotabileBean convertTo(IPrenotabile source, IPrenotabileBean destination) {
		// da iprenotabile a iprenotabilebean
		// controllo prima il caso camera
		if (source instanceof Camera) {
			Camera model = (Camera) source;
			return cmapper.getBeanFromModel(model);
		}
		// poi il caso servizio aggiuntivo
		else if (source instanceof ServizioAggiuntivo) {
			ServizioAggiuntivo model = (ServizioAggiuntivo) source;
			return samapper.getBeanFromModel(model);
		}
		return null;
	}

	@Override
	public IPrenotabile convertFrom(IPrenotabileBean source, IPrenotabile destination) {
		// da iprenotabilebean a iprenotabile
		// controllo prima il caso camera
		if (source instanceof CameraBean) {
			CameraBean bean = (CameraBean) source;
			return cmapper.getModelFromBean(bean);
		}
		// poi il caso servizio aggiuntivo
		else if (source instanceof ServizioAggiuntivoBean) {
			ServizioAggiuntivoBean bean = (ServizioAggiuntivoBean) source;
			return samapper.getModelFromBean(bean);
		}
		return null;
	}

	
}


/*
<configuration>
 <custom-converters> <!-- these are always bi-directional -->
 <converter type="com.ndovado.tecservices.mappers.converters.IPrenotabileBeanConverter" >
 <class-a>org.dozer.vo.CustomDoubleObject</class-a>
 <class-b>java.lang.Double</class-b>
 </converter>
 <!-- You are responsible for mapping everything between
 ClassA and ClassB -->
 <converter
 type="org.dozer.converters.TestCustomHashMapConverter" >
 <class-a>
 org.dozer.vo.TestCustomConverterHashMapObject
 </class-a>
 <class-b>
 org.dozer.vo.TestCustomConverterHashMapPrimeObject
 </class-b>
 </converter>

 </custom-converters>
 </configuration>
*/