package com.ndovado.tecservices.persistence.base;

import java.io.Serializable;

public interface IPersistente extends Serializable {

	public Long getId();
	
}
