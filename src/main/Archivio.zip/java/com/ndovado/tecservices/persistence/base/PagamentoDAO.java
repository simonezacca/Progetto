package com.ndovado.tecservices.persistence.base;

import com.ndovado.dominio.pagamenti.Pagamento;

public class PagamentoDAO extends GenericDAO<Pagamento> {

	public PagamentoDAO() {
		super(Pagamento.class);
		
	}

}
