package com.ndovado.tecservices.persistence.base;

import com.ndovado.dominio.servizi.ServizioComune;

public class ServizioComuneDAO extends GenericDAO<ServizioComune> {

	public ServizioComuneDAO() {
		super(ServizioComune.class);
	}
}
