package com.ndovado.tecservices.persistence.base;

import com.ndovado.dominio.core.Struttura;

public class StrutturaDAO extends GenericDAO<Struttura>{

	public StrutturaDAO() {
		super(Struttura.class);
	}

}
