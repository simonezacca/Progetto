package com.ndovado.tecservices.persistence.base;

import com.ndovado.dominio.core.Camera;

public class CameraDAO extends GenericDAO<Camera> {

	public CameraDAO() {
		super(Camera.class);
	}
}
