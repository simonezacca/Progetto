package com.ndovado.webapp.controllers;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.proxy.HibernateProxy;

import com.ndovado.dominio.core.CatalogoStrutture;
import com.ndovado.dominio.core.Struttura;
import com.ndovado.dominio.prenotazioni.Prenotazione;
import com.ndovado.tecservices.mappers.PrenotazioneMapper;
import com.ndovado.tecservices.persistence.base.PrenotazioneDAO;
import com.ndovado.webapp.beans.core.LocatarioBean;
import com.ndovado.webapp.beans.core.StrutturaBean;
import com.ndovado.webapp.beans.prenotazioni.PrenotazioneBean;

public class GestionePrenotazioneController {
	
	private CatalogoStrutture csmodel = CatalogoStrutture.getInstance();
	private PrenotazioneMapper pmapper = PrenotazioneMapper.getInstance();
	private PrenotazioneDAO pdao = new PrenotazioneDAO();
	
	
	public GestionePrenotazioneController() {
		
	}
	
	public List<PrenotazioneBean> getElencoPrenotazioniBeansByLocatario(LocatarioBean lbean) {
		List<PrenotazioneBean> pbeans = new ArrayList<PrenotazioneBean>();
		Long idLocatario = lbean.getId();
		
		Session session = pdao.getSessionFactory().openSession();
		
		Query q = session.createQuery("from Prenotazione as p where p.locatario.id = "+idLocatario);
		
		List<Prenotazione> pmodels = q.list();
		//Prenotazione prenotazione = session.get(Prenotazione.class, new Long(16));
		for (Prenotazione prenotazione : pmodels) {
			
			prenotazione = initializeAndUnproxy(prenotazione);
			PrenotazioneBean pbean = pmapper.getBeanFromModel(prenotazione);
			pbeans.add(pbean);
		}
		session.close();
		return pbeans;
		
		
	}
	
	public PrenotazioneBean doSalvaPrenotazione(StrutturaBean sbean, PrenotazioneBean pbean) {
		
		Struttura smodel = csmodel.selezionaStruttura(sbean.getId());
		Prenotazione pmodel = pmapper.getModelFromBean(pbean);
		//pmodel = smodel.getTableau().salvaOAggiornaPrenotazione(pmodel);
		pmodel = smodel.getTableau().salvaPrenotazione(pmodel);
		pbean = pmapper.getBeanFromModel(pmodel);
		
		return pbean;
		
	}
	
	public static <T> T initializeAndUnproxy(T entity) {
	    if (entity == null) {
	        throw new 
	           NullPointerException("Entity passed for initialization is null");
	    }

	    Hibernate.initialize(entity);
	    if (entity instanceof HibernateProxy) {
	        entity = (T) ((HibernateProxy) entity).getHibernateLazyInitializer()
	                .getImplementation();
	    }
	    return entity;
	}
}
