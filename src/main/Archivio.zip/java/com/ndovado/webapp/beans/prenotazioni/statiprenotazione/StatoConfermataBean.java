package com.ndovado.webapp.beans.prenotazioni.statiprenotazione;

public class StatoConfermataBean extends AStatoPrenotazioneBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public String toString() {
		return "Stato confermata";
	}

	public StatoConfermataBean() {
		// TODO Auto-generated constructor stub
	}
}
