package com.ndovado.webapp.beans.prenotazioni;

public interface IPrenotabileBean {

	/**
	 * @return
	 */
	public Float getPrezzo();

	/**
	 * @return
	 */
	public String getNomeOggettoPrenotabile();
}
