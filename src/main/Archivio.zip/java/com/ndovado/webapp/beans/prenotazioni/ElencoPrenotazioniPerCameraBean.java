package com.ndovado.webapp.beans.prenotazioni;

public class ElencoPrenotazioniPerCameraBean {

}
