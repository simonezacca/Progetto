package com.ndovado.webapp.beans.core;

public interface Identifiable {
	
	public Long getId();
	
	public Boolean isNewBean();
}
